import { Component, OnInit } from '@angular/core';
import { LikeCommentService } from '../like-comment.service';
import { Status } from './status';
import { attachEmbeddedView } from '@angular/core/src/view';
import { Likes } from './comment';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-like-comment',
  templateUrl: './like-comment.component.html',
  styleUrls: ['./like-comment.component.css']
})

export class LikeCommentComponent implements OnInit {

  displayTextbox: boolean = false;
  displayComments: Comment[];
  comments: Comment = new Comment;
  status: Status = new Status;
  like: Likes = new Likes;
  likeCount: number;
  disLikeCount: number;
  constructor(private likecommentservice: LikeCommentService) { }

  private r: ActivatedRoute;
  ngOnInit() {
    this.likecommentservice.getLikeCount(this.status.status_id).subscribe(like => {
      this.likeCount = like;

      this.likecommentservice.getDislikeCount(this.status.status_id).subscribe(data => {
        this.disLikeCount = data;

      })
    })

  }

  displayTextArea() {
    this.displayTextbox = true;
  }

  commentLikeIncre(commentId: number) {
    this.likecommentservice.commentLikeIncre(this.status.status_id, commentId).subscribe();
    location.reload();
  }
  commentDislikeIncre(commentId: number) {
    this.likecommentservice.commentDislikeIncre(this.status.status_id, commentId).subscribe();
    location.reload();
  }


  getComments(status_id: number) {

    this.likecommentservice.getComments(status_id).subscribe(data => {
      this.displayComments = data;

    });
  };
  addComments(status_id: number) {
    this.likecommentservice.addComments(status_id, this.comments).subscribe(data => {
      location.reload();
    });
  };

  updateLikeCount(status_id: number) {
    this.likecommentservice.updateLikeCount(status_id, this.like).subscribe(data => { });
    location.reload();
  };
  updateDislikeCount(status_id: number) {
    this.likecommentservice.updateDislikeCount(status_id, this.like).subscribe(data => { });
    location.reload();
  };

}
