export class Status{
    status_id:number=1;
    user_id:number=0;
}