export class Comment{
     commentId:number;
    commentText:string;
    postedBy:number;
	postedTo:number;
	dateOfPosting:Date;
	likeCount:number;
	dislikeCount:number; 
}
export class Likes{
	 like_Id:number;
	 liked_By:number=1238;
	 date_of_Like:Date;
	 like_count:boolean;
	dislike_count:boolean;
}