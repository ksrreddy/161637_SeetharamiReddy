package cap.comment.service;

import java.util.List;

import cap.comment.model.Status;

public interface IStatusService {

	boolean saveStatus(Status status);

	List<Status> getAllStatus();

	
	
}
