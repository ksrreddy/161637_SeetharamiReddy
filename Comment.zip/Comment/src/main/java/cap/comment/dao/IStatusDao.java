package cap.comment.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import cap.comment.model.Status;

@Repository("statusDao")
public interface IStatusDao extends JpaRepository<Status, Integer> {

}
