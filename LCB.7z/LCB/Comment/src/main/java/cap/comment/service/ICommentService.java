package cap.comment.service;

import java.util.List;

import cap.comment.model.Comments;

public interface ICommentService {

	List<Comments> saveComment(Comments comment);

	List<Comments> getAllComments();

	List<Comments> getAllCommentsByStatusId(Integer status_id);

	List<Comments> saveCommentByStatusId(Integer status_id, Comments comment);

	Integer updateCommentLikeCount(Integer status_id, Integer commentId);

	Integer updateCommentDislikeCount(Integer status_id, Integer commentId);

}
